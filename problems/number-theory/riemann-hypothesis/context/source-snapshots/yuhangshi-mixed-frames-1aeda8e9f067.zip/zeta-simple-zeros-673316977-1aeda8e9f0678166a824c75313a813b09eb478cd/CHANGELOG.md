# Changelog

## Unreleased

- Added prominent links to the completed Palomar registration
  `PALOMAR-2026-08-29-000004`, version 1 (29 August 2026), in both READMEs,
  identifying the registered snapshot and the three verified declarations.
- Added a Palomar-ready Challenge/Solution statement surface, Comparator
  configuration, and `formalization.yaml` metadata for the formally verified
  local supporting-plane and exact-comparison layer.  The metadata explicitly
  excludes the imported interval certificates and global zeta-zero interface
  from the formalized scope.
- Corrected the GitHub rendering of the headline display formula in the
  repository README.  No mathematical statement or numerical value changed.
- Added a pinned Lean 4 formalization, with no `sorry` in the substantive
  modules, of the abstract supporting-plane theorem, the concrete `Phi_219`
  profile, the exact radical enclosure and tax identity, and the final strict
  comparison.  The later Palomar Challenge holes are statement placeholders,
  not proof dependencies.
- Recorded the formal simplification that, once the trace-envelope alternative
  is supplied, the conditional scalar supporting-plane step does not use the
  span comparison or auxiliary slope hypotheses; the spectral derivation of
  that alternative remains outside the formalized scope, and the manuscript
  statement and numerical result are unchanged.
- Marked the completed GitHub-publication checklist items.
- Added the author's verified ORCID to the citation metadata.
- Added verification, release, and ORCID badges plus GitHub social-preview
  artwork.  No mathematical statement or numerical value was changed.
- Added the verified Zenodo version DOI `10.5281/zenodo.21926962` to the
  citation metadata, README, project metadata, provenance, and machine-readable
  result.  The archived files match the prepared `v0.1.0` deposit byte for byte.
- Aligned the article-level CFF license with the Zenodo CC BY 4.0 record; the
  repository code remains under the root MIT license.
- Added a structured GitHub Issue form for independent mathematical and
  reproducibility reports, with explicit scope and trust-boundary fields.
- Recorded the immutable `v0.1.0` commit SHA beside the permanent DOI in the
  public README.

## v0.1.0 - 2026-08-14

- Proved a two-certificate supporting-plane deduction using the certified
  seven- and nine-point inequalities on the same window.
- Obtained the research-draft candidate
  `0.6733169771424713... > 673316977/10^9` at block length `m = 219`.
- Added exact, dependency-free arithmetic checks, a zero-trust claim ledger,
  provenance and trust-boundary documentation, citation metadata, and a file
  manifest.
- Added a machine-readable result, proof and review maps, a one-command
  manifest/exact check, a GitHub Actions workflow, and a release checklist.
- Corrected one proof sentence: the supporting-plane value at `E=A_7` is
  at least `R`, not asserted to equal `R`; the proof and result are unchanged.
- Updated the author metadata and the bibliographic record for the preceding
  Schur--Jensen paper.
- Added standard project metadata, unit tests, and an upstream MIT notice.
